# JobHub — Jobs & Products

A fast static website for GitHub Pages.

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide your Pages URL.

## Customize

- Edit the job/product data in `script.js`.
- Change the email address in `index.html`.
- Replace the demo View buttons with links to individual listing pages.
- For real user-submitted listings, connect the site to Google Forms, Firebase, Supabase, or another backend.

This version is intentionally backend-free so it works immediately on GitHub Pages.
