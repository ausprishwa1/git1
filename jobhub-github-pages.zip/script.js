const jobs=[
 {type:"job",tag:"Full Time",title:"Sales Executive",meta:"Dhaka · On-site · Entry level",price:"৳20,000–30,000 / month",desc:"Join a growing sales team and build customer relationships."},
 {type:"job",tag:"Remote",title:"Content Writer",meta:"Remote · Contract · Flexible",price:"৳15,000–25,000 / month",desc:"Create clear Bengali and English content for digital products."},
 {type:"job",tag:"Part Time",title:"Customer Support Agent",meta:"Dhaka · Evening shift",price:"৳12,000–18,000 / month",desc:"Help customers through chat, phone and social channels."}
];
const products=[
 {type:"product",tag:"Featured",title:"Laptop — Business Series",meta:"Core i5 · 16GB RAM · 512GB SSD",price:"৳58,000",desc:"Reliable everyday laptop for work, study and business."},
 {type:"product",tag:"New",title:"Wireless Headphones",meta:"Bluetooth · Noise reduction · USB-C",price:"৳2,450",desc:"Comfortable headphones for calls, music and travel."},
 {type:"product",tag:"Popular",title:"Office Backpack",meta:"Water resistant · 15.6″ laptop fit",price:"৳1,250",desc:"Practical backpack for office, university and commuting."}
];

const jobGrid=document.querySelector("#jobGrid"), productGrid=document.querySelector("#productGrid");
function card(x){
 return `<article class="card" data-type="${x.type}" data-search="${(x.title+" "+x.tag+" "+x.meta+" "+x.desc).toLowerCase()}">
   <span class="tag">${x.tag}</span><h3>${x.title}</h3>
   <div class="meta">${x.meta}<br>${x.desc}</div>
   <div class="card-foot"><div class="price">${x.price}</div><button class="mini-btn">View</button></div>
 </article>`;
}
jobGrid.innerHTML=jobs.map(card).join(""); productGrid.innerHTML=products.map(card).join("");

const allCards=[...document.querySelectorAll(".card")];
function filter(){
 const q=document.querySelector("#searchInput").value.toLowerCase().trim();
 const type=document.querySelector("#typeFilter").value;
 allCards.forEach(c=>{
   c.hidden=!(c.dataset.search.includes(q)&&(type==="all"||c.dataset.type===type));
 });
}
document.querySelector("#searchBtn").onclick=filter;
document.querySelector("#searchInput").oninput=filter;
document.querySelector("#typeFilter").onchange=filter;
document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>{document.querySelector("#searchInput").value=b.dataset.query;filter();window.scrollTo({top:document.querySelector("#jobs").offsetTop-80,behavior:"smooth"})});
document.querySelectorAll(".mini-btn").forEach(b=>b.onclick=()=>alert("Connect this button to your job/product details page or database."));
